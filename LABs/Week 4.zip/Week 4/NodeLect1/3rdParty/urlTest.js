const url = new URL('https://www.borgwarner.com/company')

console.log(url.protocol)
console.log(url.host)
console.log(url.pathname)
console.log(url.search)
console.log(url.hash)
