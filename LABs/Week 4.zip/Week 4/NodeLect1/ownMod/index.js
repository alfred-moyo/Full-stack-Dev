var randomInt = require("./rand")

console.log(randomInt());